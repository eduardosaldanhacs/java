public class App {
    public static void main(String[] args) {
        System.out.println("Exemplo Herança");
        Pessoa p1 = new Pessoa("Edu", "Part", "Brasileiro");
        //p1.imprimirDados();

        Aluno a1 = new Aluno("Edu", "Partenon", "Brasileiro", 598345, "Ciência da Computação");
        a1.imprimirDadosAluno();

        Professor t1 = new Professor("Adri", "FAPA", "Brasileira", 54353, "ADS");
        t1.imprimirDados();
    }
}
