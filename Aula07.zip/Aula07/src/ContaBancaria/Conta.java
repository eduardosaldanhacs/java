package ContaBancaria;

public class Conta {
    private Gerente gerente;
    private double saldo;

    public Conta () {

    }

    public Conta(Class Gerente, double saldo) {

    }

    public void exibeGerente(Class Gerente, double saldo) {

    }
}
