package ContaBancaria;

public class Assistente extends Funcionario {
    private String especializacao;

    public Assistente() {

    }

    public Assistente(String nome, String endereco, String sexo, String ano, String especializacao) {
        super(nome, endereco, sexo, ano);
        this.especializacao = especializacao;
    }

    public String getEspecializacao() {
        return especializacao;
    }

    public void setEspecializacao(String especializacao) {
        this.especializacao = especializacao;
    }
}
