package ContaBancaria;

public class Funcionario {
    private String nome;
    private String endereco;
    private String sexo;
    private String ano;

    public Funcionario() {

    }
    public Funcionario(String nome, String endereco, String sexo, String ano) {
        this.nome = nome;
        this.endereco = endereco;
        this.sexo = sexo;
        this.ano = ano;
    }

    public String getNome() {
        return nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getSexo() {
        return sexo;
    }

    public String getAno() {
        return ano;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public void setAno(String ano) {
        this.ano = ano;
    }
}
