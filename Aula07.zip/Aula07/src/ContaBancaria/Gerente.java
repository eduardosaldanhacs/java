package ContaBancaria;

public class Gerente extends Funcionario {
    private int nivel;


    public Gerente() {

    }

    public Gerente(String nome, String endereco, String sexo, String ano, int nivel) {
        super(nome, endereco, sexo, ano);
        this.nivel = nivel;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }
}
