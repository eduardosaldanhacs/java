package ContaBancaria;

public class AssistenteAdministrativo extends Assistente{
    private String turno;
    private double adicional;
    public AssistenteAdministrativo() {

    }

    public AssistenteAdministrativo(String nome, String endereco, String sexo, String ano, String especializacao, String turno, double adicional) {
        super(nome, endereco, sexo, ano, especializacao);
        this.turno = turno;
        this.adicional = adicional;
    }

    public String getTurno() {
        return turno;
    }

    public double getAdicional() {
        return adicional;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    public void setAdicional(double adicional) {
        this.adicional = adicional;
    }

    public double recebeAdicional(String turno, double adicional) {
        if(turno == "noturno") {
            return adicional;
        } else {
            return 0.00;
        }
    }
}
