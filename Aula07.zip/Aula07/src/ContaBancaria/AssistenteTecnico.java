package ContaBancaria;

public class AssistenteTecnico extends Assistente {
    private double bonus;

    public AssistenteTecnico() {

    }

    public AssistenteTecnico(String nome, String endereco, String sexo, String ano, String especializacao, double bonus) {
        super(nome, endereco, sexo, ano, especializacao);
        this.bonus = bonus;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }


}
