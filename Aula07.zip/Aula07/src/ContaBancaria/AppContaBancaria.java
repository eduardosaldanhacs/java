package ContaBancaria;

public class AppContaBancaria {
    Funcionario f1 = new Funcionario();
}
