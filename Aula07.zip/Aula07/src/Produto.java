public class Produto {
    private int codigo;
    private String descricao;
    private double preco;
    private String fabricante;

    public Produto() {
    }

    public Produto(int codigo, String descricao, double preco, String fabricante){
        this.codigo = codigo;
        this.descricao = descricao;
        this.preco = preco;
        this.fabricante = fabricante;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    public String getFabricante() {
        return fabricante;
    }
    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }
}