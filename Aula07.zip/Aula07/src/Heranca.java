public class Heranca {
}
